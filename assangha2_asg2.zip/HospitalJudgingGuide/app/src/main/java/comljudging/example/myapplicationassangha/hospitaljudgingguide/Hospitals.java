package comljudging.example.myapplicationassangha.hospitaljudgingguide;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class Hospitals extends ActionBarActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospitals);
        Intent intent = getIntent();
        String province= getIntent().getExtras().getString("Province");
        String region= getIntent().getExtras().getString("Region");
        String year= getIntent().getExtras().getString("Year");
        ListView lv = (ListView) findViewById(R.id.hospitals);

        final Adapter.DBHelper myDbHelper = new Adapter.DBHelper(this);
        db = myDbHelper.getWritableDatabase();
        final Cursor curs = db.rawQuery("SELECT ifnull(*,'unknown') FROM indicator where  region like '%" + region + "%'", null);
        CAAdapter adapt = new CAAdapter(this, curs);
        lv.setAdapter(adapt);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_hospitals, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.activity_about) {
            Intent intent=new Intent(this,About.class);
            startActivityForResult(intent,0);
            return true;
        }
        if (id == R.id.activity_help) {
            Intent intent=new Intent(this,Help.class);
            startActivityForResult(intent,0);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
