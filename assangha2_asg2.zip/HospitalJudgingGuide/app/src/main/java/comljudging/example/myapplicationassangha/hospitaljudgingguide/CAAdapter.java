package comljudging.example.myapplicationassangha.hospitaljudgingguide;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class CAAdapter extends CursorAdapter {
    public CAAdapter(Context context, Cursor cursor) {
        super(context, cursor,0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.activity_hospitals, parent,false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        TextView name = (TextView) view.findViewById(R.id.list);
        String body = cursor.getString(cursor.getColumnIndexOrThrow("hospital"));
        name.setText(body);
    }
}