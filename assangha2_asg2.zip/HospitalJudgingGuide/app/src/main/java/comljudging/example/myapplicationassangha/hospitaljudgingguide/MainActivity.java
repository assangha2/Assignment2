package comljudging.example.myapplicationassangha.hospitaljudgingguide;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.sql.SQLException;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        //creating database
        Adapter db = new Adapter(this);
        Adapter.DBHelper dbh = new Adapter.DBHelper(this);
        try {
                db.open();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //downloading data from csv file stored in google drive
            //code taken from friend for help to download data
//            if (!db.doesTableExist()) {
  //             db.drop();
        if(!db.doesTableExist()) {

            URL url = null;
                try {
                    url = new URL("https://drive.google.com/uc?export=download&id=0BxYwHih8QFfweDJCVDFiYVVwODQ");
                    Log.d("Get", " URL " + url);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) url.openConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    c.setRequestMethod("GET");
                    Log.d("Set ", "GET method");
                } catch (ProtocolException e) {
                    e.printStackTrace();
                }
                try {
                    c.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.d("Connect ", " C" + c);
                InputStream is = null;
                try {
                    is = c.getInputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String line = null;
                //inserting values in database from csv file by downloading data from it
                try {
                    while ((line = br.readLine()) != null) {
                        String[] v = line.split(",");
                        String reportinglevel = v[0];
                        String hospital = v[1];
                        String hospitaltype = v[2];
                        String region = v[3];
                        String province = v[4];
                        String indicator = v[5];
                        String year = v[6];
                        String result = v[7];
                        String notes = v[8];
                        String suppression = v[9];
                        String comparison = v[10];
                        String tot = v[11];
                            db.insertValues(reportinglevel, hospital, hospitaltype, region, province, indicator, year, result, notes, suppression, comparison, tot);
                        Log.i("msg", hospital);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                db.close();
                Log.d("Finished", "FINISHED");
//              Toast.makeText(getApplicationContext(), "Update Finished", Toast.LENGTH_LONG).show();
//            } else {
//               Toast.makeText(getApplicationContext(), "Database already exist", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(getBaseContext(),"Database already built",Toast.LENGTH_LONG).show();
        }

        Spinner spinner = (Spinner) findViewById(R.id.province);
        Spinner spinner2 = (Spinner) findViewById(R.id.region);
        Spinner spinner3 = (Spinner) findViewById(R.id.year);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.province, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        final String province = spinner.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.region, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        final String region = spinner2.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.year, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);
        final String year = spinner3.getSelectedItem().toString();

        Button btn1=(Button) findViewById(R.id.filter);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Hospitals.class);
                intent.putExtra("Province",province);
                intent.putExtra("Region",region);
                intent.putExtra("Year",year);
                startActivity(intent);

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement


        if (id == R.id.activity_about) {
            Intent intent=new Intent(this,About.class);
            startActivityForResult(intent,0);
            return true;
        }
        if (id == R.id.activity_help) {
            Intent intent=new Intent(this,Help.class);
            startActivityForResult(intent,0);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}