package comljudging.example.myapplicationassangha.hospitaljudgingguide;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by assangha on 15/08/15.
 */
public class Adapter {

    static final String DBPATH = "/data/data/comljudging.example.myapplicationassangha.hospitaljudgingguide/databases/assignment.db";

    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "assignment.db";

    public static final String TABLE = "indicator";

    // Labels Table Columnstatics names
    public static final String REPORTINGLEVEL = "reportinglevel";
    public static final String HOSPITAL = "hospital";
    public static final String HOSPITALTYPE = "hospitaltype";
    public static final String REGION = "region";
    public static final String PROVINCE = "province";
    public static final String INDICATOR = "indicator";
    public static final String YEAR = "year";
    public static final String RESULT = "result";
    public static final String NOTES = "notes";
    public static final String SUPPRESSION = "suppression";
    public static final String COMPARISON = "comparisons";
    public static final String TOT = "tot";

    public static final String QUERY = "CREATE TABLE " + TABLE + "("
            + "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            + REPORTINGLEVEL + " TEXT ,"
            + HOSPITAL + " TEXT ,"
            + HOSPITALTYPE + " TEXT ,"
            + REGION + " TEXT ,"
            + PROVINCE + " TEXT ,"
            + INDICATOR + " TEXT ,"
            + YEAR + " TEXT ,"
            + RESULT + " TEXT ,"
            + NOTES + " TEXT ,"
            + SUPPRESSION + " TEXT ,"
            + COMPARISON + " TEXT ,"
            + TOT + " TEXT )";
    private static final String TAG = "SQL";


    Context context;
    DBHelper dbh;
    static SQLiteDatabase sqldb;


    public Adapter(Context context) {
        this.context = context;
        dbh = new DBHelper(context);
    }

    public static class DBHelper extends SQLiteOpenHelper {

        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);

        }

        @Override
        public void onCreate(SQLiteDatabase db) {

                db.execSQL(QUERY);
           // }
             // is function ne tere query chala dene aa
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS indicator");
            onCreate(db);
        }

    }


    //open the database
    public Adapter open() throws SQLException {
        sqldb=dbh.getWritableDatabase();
        return this;
    }
    //close the database
    public void close(){
        dbh.close();
    }

    public void insertValues(String reportinglevel,String hospital,String hospitaltype,String region,String province,String indicator,String year,String result,String notes,String suppression,String comparison,String tot){
        ContentValues initial=new ContentValues();
        initial.put(REPORTINGLEVEL,reportinglevel);
        initial.put(HOSPITAL,hospital);
        initial.put(HOSPITALTYPE,hospitaltype);
        initial.put(REGION,region);
        initial.put(PROVINCE,province);
        initial.put(INDICATOR,indicator);
        initial.put(YEAR,year);
        initial.put(RESULT,result);
        initial.put(NOTES,notes);
        initial.put(SUPPRESSION,suppression);
        initial.put(COMPARISON,comparison);
        initial.put(TOT,tot);

        sqldb.insert(TABLE, null, initial);
    }
    //insert values for french table

    public Cursor getAllData(){
        sqldb = dbh.getWritableDatabase();
        Cursor res = sqldb.rawQuery("select _id,hospital from "+ TABLE+" where hospital IS NOT NULL and year like '%2013%'", null);
        return res;
    }
    public void drop(){sqldb.execSQL("DELETE FROM indicator");}

    public boolean doesTableExist() {
        Cursor cursor = sqldb.rawQuery("select _id,hospital from "+TABLE+" where hospital IS NOT NULL and year like '%2013%'", null);

        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;
    }

}

